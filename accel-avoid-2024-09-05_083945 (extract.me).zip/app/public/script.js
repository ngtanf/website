document.addEventListener('DOMContentLoaded', () => {
  const commentsDiv = document.getElementById('comments');
  const form = document.getElementById('comment-form');
  const nameInput = document.getElementById('name');
  const commentInput = document.getElementById('comment');

  const pageName = window.location.pathname.split('/').pop() || 'index.html';

  // ユーザーIDを取得または生成
  let userId = localStorage.getItem('userId');
  if (!userId) {
    userId = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
    localStorage.setItem('userId', userId);
  }

  function loadComments() {
    fetch(`/api/comments/${pageName}`)
      .then(response => response.json())
      .then(comments => {
        comments.sort((a, b) => new Date(b.date) - new Date(a.date));
        commentsDiv.innerHTML = comments.map(comment => `
          <div class="comment" data-id="${comment.id}" data-user-id="${comment.userId}">
            <strong>${comment.name}</strong>
            <p>${comment.comment}</p>
            <small>${new Date(comment.date).toLocaleString()}</small>
            ${comment.userId === userId ? '<button class="delete-btn">削除</button>' : ''}
          </div>
        `).join('');

        // 削除ボタンにイベントリスナーを追加
        document.querySelectorAll('.delete-btn').forEach(btn => {
          btn.addEventListener('click', deleteComment);
        });
      });
  }

  function deleteComment(e) {
    const commentDiv = e.target.closest('.comment');
    const commentId = commentDiv.dataset.id;

    fetch(`/api/comments/${pageName}/${commentId}`, {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ userId }),
    })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        commentDiv.remove();
      } else {
        alert('コメントの削除に失敗しました');
      }
    });
  }

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const name = nameInput.value;
    const comment = commentInput.value;

    fetch(`/api/comments/${pageName}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ name, comment, userId }),
    })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        commentInput.value = ''; // コメント入力欄のみクリア
        loadComments();
      }
    });
  });

  loadComments();
});