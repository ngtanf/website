const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const escapeHtml = require('escape-html'); // HTMLエスケープのためのモジュール

const app = express();
const port = process.env.PORT || 3000;

app.use(bodyParser.json());
app.use(express.static('public'));

const commentsFile = path.join(__dirname, '.data', 'comments.json');

// ユーザー識別子を生成する関数
function generateUserId() {
  return crypto.randomBytes(16).toString('hex');
}

// 不適切な単語をチェックするためのブラックリスト
const blacklist = ['sex', '性', '股', '違法', '糞', 'クソ', '死', 'fuck']; // ブラックリストの単語

// 入力が不適切かチェックする関数
function containsBadWords(text) {
  return blacklist.some(word => text.toLowerCase().includes(word));
}

// コメントを取得
app.get('/api/comments/:page', (req, res) => {
  const page = req.params.page;
  fs.readFile(commentsFile, 'utf8', (err, data) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'コメントの読み込みに失敗しました' });
    }
    const comments = JSON.parse(data || '{}');
    res.json(comments[page] || []);
  });
});

// コメントを追加
app.post('/api/comments/:page', (req, res) => {
  const page = req.params.page;
  const { name, comment, userId } = req.body;

  if (containsBadWords(name) || containsBadWords(comment)) {
    return res.status(400).json({ error: '不適切な内容が含まれています' });
  }

  fs.readFile(commentsFile, 'utf8', (err, data) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'コメントの読み込みに失敗しました' });
    }
    const comments = JSON.parse(data || '{}');
    if (!comments[page]) comments[page] = [];
    const id = crypto.randomBytes(16).toString('hex');
    const newUserId = userId || generateUserId();
    comments[page].push({ id, name: escapeHtml(name), comment: escapeHtml(comment), date: new Date().toISOString(), userId: newUserId });

    fs.writeFile(commentsFile, JSON.stringify(comments, null, 2), (err) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ error: 'コメントの保存に失敗しました' });
      }
      res.json({ success: true, id, userId: newUserId });
    });
  });
});

// コメントを削除
app.delete('/api/comments/:page/:id', (req, res) => {
  const { page, id } = req.params;
  const { userId } = req.body; // クライアントから送信されたユーザーID

  fs.readFile(commentsFile, 'utf8', (err, data) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'コメントの読み込みに失敗しました' });
    }

    const comments = JSON.parse(data || '{}');
    if (!comments[page]) {
      return res.status(404).json({ error: 'ページが見つかりません' });
    }

    const index = comments[page].findIndex(comment => comment.id === id);
    if (index === -1) {
      return res.status(404).json({ error: 'コメントが見つかりません' });
    }

    // ユーザーIDが一致するか確認
    if (comments[page][index].userId !== userId) {
      return res.status(403).json({ error: '削除権限がありません' });
    }

    comments[page].splice(index, 1);

    fs.writeFile(commentsFile, JSON.stringify(comments, null, 2), (err) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ error: 'コメントの削除に失敗しました' });
      }
      res.json({ success: true });
    });
  });
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
